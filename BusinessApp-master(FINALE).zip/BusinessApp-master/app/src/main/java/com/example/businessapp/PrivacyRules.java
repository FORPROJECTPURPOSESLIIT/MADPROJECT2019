package com.example.businessapp;

public class PrivacyRules {

    private String rules;

    public PrivacyRules() {
    }

    public PrivacyRules(String rules) {
        this.rules = rules;
    }

    public String getRules() {
        return rules;
    }

    public void setRules(String rules) {
        this.rules = rules;
    }
}
