package com.example.businessapp;

import android.support.annotation.NonNull;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class FirebaseDatabaseHelperPrivacy {

     private FirebaseDatabase mDatabase;
     private DatabaseReference mReferencePrivacy;
     private List<PrivacyRules> privacy = new ArrayList<>();

     public interface DataStatus{

        void DataIsLoaded(List<PrivacyRules> privacy, List<String> keys);

            void DataIsInserted();
            void DataIsUpdated();
            void DataIsDeleted();




     }


    public FirebaseDatabaseHelperPrivacy() {

        mDatabase = FirebaseDatabase.getInstance();
        mReferencePrivacy = mDatabase.getReference("privacy");

    }

    public void readPrivacy(final DataStatus dataStatus ){

        mReferencePrivacy.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                privacy.clear();
                List<String> keys = new ArrayList<>();
                 for(DataSnapshot keyNode : dataSnapshot.getChildren()){

                     keys.add(keyNode.getKey());
                     PrivacyRules privacy1 = keyNode.getValue(PrivacyRules.class);
                     privacy.add(privacy1);

                 }
                 dataStatus.DataIsLoaded(privacy, keys);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }

    public void addPrivacy(PrivacyRules privacyRules, final DataStatus dataStatus){

        String key = mReferencePrivacy.push().getKey();
        mReferencePrivacy.child(key).setValue(privacyRules).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void aVoid) {

                dataStatus.DataIsInserted();

            }
        });


    }
    public void updatePrivacy(String key, PrivacyRules privacyRules, final DataStatus dataStatus){

         mReferencePrivacy.child(key).setValue(privacyRules).addOnSuccessListener(new OnSuccessListener<Void>() {
             @Override
             public void onSuccess(Void aVoid) {

                 dataStatus.DataIsUpdated();
             }
         });
    }
    public void deletePrivacy(String key, final DataStatus dataStatus){

         mReferencePrivacy.child(key).setValue(null).addOnSuccessListener(new OnSuccessListener<Void>() {
             @Override
             public void onSuccess(Void aVoid) {

                 dataStatus.DataIsDeleted();

             }
         });
    }
}
