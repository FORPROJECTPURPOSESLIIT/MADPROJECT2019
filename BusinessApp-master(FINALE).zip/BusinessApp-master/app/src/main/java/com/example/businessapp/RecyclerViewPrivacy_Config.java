package com.example.businessapp;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.List;

public class RecyclerViewPrivacy_Config {

    private Context mContext;
    private PrivacyAdapter mPrivacyAdapter;

    public void setConfig(RecyclerView recyclerView, Context context, List<PrivacyRules> privacyRules, List<String> keys){
        mContext = context;
        mPrivacyAdapter = new PrivacyAdapter(privacyRules, keys);
        recyclerView.setLayoutManager(new LinearLayoutManager(context));
        recyclerView.setAdapter(mPrivacyAdapter);

    }


    class PrivacyItemView extends RecyclerView.ViewHolder{

        private TextView mPrivacy;

        private String key;

        public PrivacyItemView(ViewGroup parent){

            super(LayoutInflater.from(mContext).inflate(R.layout.privacy_list_item, parent, false));

            mPrivacy = (TextView) itemView.findViewById(R.id.rules);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    Intent intent = new Intent(mContext, PrivacyDetailsActivity.class);
                     intent.putExtra("key", key);
                     intent.putExtra("rules", mPrivacy.getText().toString());

                     mContext.startActivity(intent);
                }
            });
        }

        public void bind(PrivacyRules privacy, String key){

            mPrivacy.setText(privacy.getRules());
            this.key = key;
        }

    }

    class PrivacyAdapter extends RecyclerView.Adapter<PrivacyItemView>{

        private List<PrivacyRules> mPrivacyList;
        private List<String> mkeys;

        public PrivacyAdapter(List<PrivacyRules> mPrivacyList, List<String> mkeys) {
            this.mPrivacyList = mPrivacyList;
            this.mkeys = mkeys;
        }

        @Override
        public int getItemCount() {
            return mPrivacyList.size();
        }

        @Override
        public void onBindViewHolder(PrivacyItemView holder, int position) {

            holder.bind(mPrivacyList.get(position), mkeys.get(position));
        }


        @Override
        public PrivacyItemView onCreateViewHolder(ViewGroup parent, int viewType) {
            return new PrivacyItemView(parent);
        }
    }




}
