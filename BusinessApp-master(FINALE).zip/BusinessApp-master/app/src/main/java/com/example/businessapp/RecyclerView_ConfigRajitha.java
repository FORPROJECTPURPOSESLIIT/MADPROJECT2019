package com.example.businessapp;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.List;

public class RecyclerView_ConfigRajitha {
    private Context mContext;
    private FoodsAdapter mFoodsAdapter;
    public void setConfig(RecyclerView recyclerView, Context context,List<Foods> foods,List<String> keys)
    {

        mContext =context;
        mFoodsAdapter = new FoodsAdapter(foods,keys);
        recyclerView.setLayoutManager(new LinearLayoutManager(context));
        recyclerView.setAdapter(mFoodsAdapter);

    }


    class FoodItemView extends RecyclerView.ViewHolder
    {

        private TextView mName;
        private TextView mDescription;
        private TextView mPrice;


        private String key;

        public FoodItemView(ViewGroup parent)
        {
            super(LayoutInflater.from(mContext).
                    inflate(R.layout.food_list_item,parent,false));

            mName=(TextView)itemView.findViewById(R.id.title_txt);
            mDescription=(TextView)itemView.findViewById(R.id.descriptionTxt);
            mPrice=(TextView)itemView.findViewById(R.id.priceView);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(mContext, FoodDetailsActivity.class);
                    intent.putExtra("key",key);
                    intent.putExtra("FoodName",mName.getText().toString());
                    intent.putExtra("Description",mDescription.getText().toString());
                    intent.putExtra("Price",mPrice.getText().toString());

                    mContext.startActivity(intent);
                }
            });

        }

        public void bind(Foods foods,String key)
        {
            mName.setText(foods.getName());
            mDescription.setText(foods.getDescription());
            mPrice.setText(foods.getPrice());
            this.key=key;
        }
    }
    class FoodsAdapter extends RecyclerView.Adapter<FoodItemView>
    {
        private List <Foods> mFoodList;
        private List <String> mKeys;

        public FoodsAdapter(List<Foods> mFoodList, List<String> mKeys) {
            this.mFoodList = mFoodList;
            this.mKeys = mKeys;
        }

        @NonNull
        @Override
        public FoodItemView onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            return new FoodItemView(parent);
        }

        @Override
        public void onBindViewHolder(@NonNull FoodItemView holder, int position) {

            holder.bind(mFoodList.get(position),mKeys.get(position));
        }

        @Override
        public int getItemCount() {
            return mFoodList.size();
        }
    }

}
