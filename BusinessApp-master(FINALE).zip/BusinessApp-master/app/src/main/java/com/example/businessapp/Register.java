package com.example.businessapp;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Register extends AppCompatActivity {

    private EditText email, name, phone, password, re_password;
    private String email_user,  name_user, password_user, re_password_user, phone_user, review_user;
    private String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";
    private Button register;
    private FirebaseAuth firebaseAuth;
    private ProgressDialog progress;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        firebaseAuth = FirebaseAuth.getInstance();
        progress = new ProgressDialog(this);

        email = findViewById(R.id.email_reg);
        name = findViewById(R.id.name_reg_id);
        phone = findViewById(R.id.phone_reg);
        password = findViewById(R.id.password_reg);
        re_password = findViewById(R.id.repassword_reg);

    }

    public void registration(View view){

        name_user = name.getText().toString();
        email_user = email.getText().toString().trim();
        phone_user = phone.getText().toString().trim();
        password_user = password.getText().toString().trim();
        re_password_user = re_password.getText().toString().trim();



        if(validateDetails()==true){
            firebaseAuth.createUserWithEmailAndPassword(email_user, password_user).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    if (task.isSuccessful()){
                        progress.setTitle("Please wait..!");
                        progress.setMessage("You're connecting with our Servers..");
                        progress.show();

                        UserProfile userProfile = new UserProfile(email_user, name_user, phone_user);

                        FirebaseDatabase.getInstance().getReference("Users")
                                .child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                                .setValue(userProfile).addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                if(task.isSuccessful()){
                                    Toast.makeText(getApplicationContext(),"Registration Successful!", Toast.LENGTH_SHORT).show();
                                    startActivity(new Intent(Register.this, Home.class));
                                }else{
                                    Toast.makeText(getApplicationContext(),"Registration Unsuccessful!", Toast.LENGTH_SHORT).show();
                                }
                            }
                        });
                        //uploadToFireBase();
                    }else{
                        Toast.makeText(getApplicationContext(),"Registration Unsuccessful, User already been Registered!", Toast.LENGTH_LONG).show();
                    }

                }
            });
        }

    }

    public boolean validateDetails(){

        progress.setTitle("Please wait..!");
        progress.setMessage("You're connecting with our Servers..");
        progress.show();

        Runnable progressRunnable = new Runnable() {

            @Override
            public void run() {
                progress.cancel();
            }
        };

        Handler pdCanceller = new Handler();
        pdCanceller.postDelayed(progressRunnable, 2000);


        if(name_user.isEmpty() || email_user.isEmpty() || password_user.isEmpty() || re_password_user.isEmpty() || phone_user.isEmpty()){
            Toast.makeText(getApplicationContext(),"Fill all the Details!", Toast.LENGTH_LONG).show();
            return false;
        }else if(password_user.length() < 6){
            Toast.makeText(getApplicationContext(),"Password should contain six letters or more!", Toast.LENGTH_LONG).show();
            return false;
        }else if(phone_user.length() <= 9){
            Toast.makeText(getApplicationContext(),"Invalid Phone Number!", Toast.LENGTH_LONG).show();
            return false;
        }        else{
            if (email_user.matches(emailPattern)){
                if(password_user.equals(re_password_user)){
                    //Toast.makeText(getApplicationContext(),"Passwords checked ***********", Toast.LENGTH_LONG).show();
                    return true;
                }else{
                    Toast.makeText(getApplicationContext(),"Passwords should be the Same!", Toast.LENGTH_LONG).show();
                    return false;
                }
            }else{
                Toast.makeText(getApplicationContext(),"Invalid email address!", Toast.LENGTH_LONG).show();
                return false;
            }
        }
    }

    public void uploadToFireBase(){
        FirebaseDatabase firebaseDatabase = FirebaseDatabase.getInstance();
        DatabaseReference myRef = firebaseDatabase.getReference(firebaseAuth.getUid());

        review_user = "Suggessions : ";

        UserProfile userProfile = new UserProfile(email_user, name_user, phone_user, review_user);
        myRef.setValue(userProfile);
    }


}
