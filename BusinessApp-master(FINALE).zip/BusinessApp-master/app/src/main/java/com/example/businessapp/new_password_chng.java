package com.example.businessapp;

import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class new_password_chng extends AppCompatActivity {

    private Button submit_pwd;
    private TextView new_pwd;
    private FirebaseUser firebaseUser;
    private FirebaseAuth firebaseAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_password_chng);

        submit_pwd = findViewById(R.id.btnsubmit);
        new_pwd = findViewById(R.id.new_password);

        firebaseUser = FirebaseAuth.getInstance().getCurrentUser();

        submit_pwd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String user_password_new =  new_pwd.getText().toString();

                firebaseUser.updatePassword(user_password_new).addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if(task.isSuccessful()){
                            Toast.makeText(new_password_chng.this, "Password Changed Successfully!", Toast.LENGTH_SHORT).show();
                            finish();
                        }else{
                            Toast.makeText(new_password_chng.this, "Error in changing Password!", Toast.LENGTH_SHORT).show();
                            Log.d("tag", "oncomplete....." + task.getException().toString());
                        }
                    }
                });
            }
        });



    }
}
