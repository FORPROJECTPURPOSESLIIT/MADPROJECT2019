package com.example.businessapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.view.View;

import java.util.List;

public class PrivacyListActivity extends AppCompatActivity {

    private RecyclerView mRecyclerViewPrivacy;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_privacy_list);
        mRecyclerViewPrivacy = (RecyclerView) findViewById(R.id.RecycleView_privacy);
        new FirebaseDatabaseHelperPrivacy().readPrivacy(new FirebaseDatabaseHelperPrivacy.DataStatus() {
            @Override
            public void DataIsLoaded(List<PrivacyRules> privacy, List<String> keys) {

                new RecyclerViewPrivacy_Config().setConfig(mRecyclerViewPrivacy, PrivacyListActivity.this, privacy, keys);
                findViewById(R.id.loadingBar).setVisibility(View.GONE);
            }

            @Override
            public void DataIsInserted() {

            }

            @Override
            public void DataIsUpdated() {

            }

            @Override
            public void DataIsDeleted() {

            }
        });
    }
}
