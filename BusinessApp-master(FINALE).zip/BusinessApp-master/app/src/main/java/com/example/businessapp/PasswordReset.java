package com.example.businessapp;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;

public class PasswordReset extends AppCompatActivity {

    private Button pswrd_btn_reset;
    private EditText email_reset;
    private FirebaseAuth firebaseAuth;
    private String email;
    private ProgressDialog progress;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_password_reset);

        progress = new ProgressDialog(this);

        pswrd_btn_reset = findViewById(R.id.reset_btn);
        email_reset = findViewById(R.id.email_reset);
        firebaseAuth = firebaseAuth.getInstance();

        pswrd_btn_reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                email = email_reset.getText().toString().trim();

                if(validate() == true){
                    progress.setMessage("Searching in DataBase..");
                    progress.show();

                    Runnable progressRunnable = new Runnable() {

                        @Override
                        public void run() {
                            progress.cancel();
                        }
                    };

                    Handler pdCanceller = new Handler();
                    pdCanceller.postDelayed(progressRunnable, 2000);

                    firebaseAuth.sendPasswordResetEmail(email).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if(task.isSuccessful()){
                                Toast.makeText(PasswordReset.this, "Password reset E-mail sent!", Toast.LENGTH_SHORT).show();
                                finish();
                                startActivity(new Intent(PasswordReset.this, Login.class));
                            }else {
                                Toast.makeText(PasswordReset.this, "This E-mail is not in our Records..", Toast.LENGTH_LONG).show();
                            }
                        }
                    });

                }
            }
        });
    }

    public boolean validate(){
        if(email_reset.getText().toString().trim().isEmpty()){
            Toast.makeText(this, "Please enter a valid E-mail", Toast.LENGTH_SHORT).show();
            return false;
        }else
            return true;
    }


}
