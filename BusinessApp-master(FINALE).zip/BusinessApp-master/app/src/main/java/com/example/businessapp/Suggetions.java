package com.example.businessapp;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class Suggetions extends AppCompatActivity {

    private FirebaseAuth firebaseAuth;
    private FirebaseDatabase firebaseDatabase;
    private EditText sugTxt, name, phone, email;
    private Button delete, submit;
    private String email_update, name_update, phone_update, address;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_suggetions);


        sugTxt = findViewById(R.id.suggestionText);
        name = findViewById(R.id.name_reg_id);
        phone = findViewById(R.id.phone_reg);
        email = findViewById(R.id.email_reg);

        delete = findViewById(R.id.btndelete);
        submit = findViewById(R.id.btnsubmit);

        firebaseAuth = FirebaseAuth.getInstance();
        firebaseDatabase = FirebaseDatabase.getInstance();

        //final DatabaseReference databaseReference = firebaseDatabase.getReference(firebaseAuth.getUid());

        FirebaseUser user=FirebaseAuth.getInstance().getCurrentUser();
        final String userid=user.getUid();

        final DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("Users");
        
        databaseReference.child(userid).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                UserProfile userProfile = dataSnapshot.getValue(UserProfile.class);

                name.setEnabled(false);
                phone.setEnabled(false);
                email.setEnabled(false);

                name_update = userProfile.getName();
                email_update = userProfile.getEmail();
                phone_update = userProfile.getPhoneNumber();
                address = userProfile.getAddress();

                name.setText("Name : " + userProfile.getName());
                phone.setText("Phone no : " + userProfile.getPhoneNumber());
                email.setText("E-mail : " + userProfile.getEmail());
                sugTxt.setText(userProfile.getReview());
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(Suggetions.this, databaseError.getCode(),  Toast.LENGTH_SHORT).show();
            }
        });


        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sugTxt.setText("Suggessions : ");

                String review = sugTxt.getText().toString();

                UserProfile userProfile = new UserProfile(email_update, name_update, phone_update, review, address);

                databaseReference.child(userid).setValue(userProfile);

                finish();
                startActivity(getIntent());
            }
        });

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String review = sugTxt.getText().toString();

                UserProfile userProfile = new UserProfile(email_update, name_update, phone_update, review, address);

                databaseReference.child(userid).setValue(userProfile);

                finish();
                startActivity(getIntent());
            }
        });
    }


}
