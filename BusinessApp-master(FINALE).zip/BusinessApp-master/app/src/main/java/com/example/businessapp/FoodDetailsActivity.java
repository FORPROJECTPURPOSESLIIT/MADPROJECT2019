package com.example.businessapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.List;

public class FoodDetailsActivity extends AppCompatActivity {

    private EditText mFood_editText;
    private EditText mDesc_editText;
    private EditText mPrice_editText;


    private Button mUpdate_btn;
    private Button mDelete_btn;
    private Button mBack_btn;

    private String key;
    private String FoodName;
    private String Description;
    private String Price;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_food_details);

        key = getIntent().getStringExtra("key");
        FoodName = getIntent().getStringExtra("FoodName");
        Description = getIntent().getStringExtra("Description");
        Price = getIntent().getStringExtra("Price");


        mFood_editText = findViewById(R.id.insertFoodName);
        mFood_editText.setText(FoodName);
        mDesc_editText = findViewById(R.id.insertDescription);
        mDesc_editText.setText(Description);
        mPrice_editText = findViewById(R.id.insertPrice);
        mPrice_editText.setText(Price);


        mUpdate_btn = findViewById(R.id.update);
        mDelete_btn = findViewById(R.id.delete);
        mBack_btn = findViewById(R.id.back);

        mUpdate_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Foods foods = new Foods();
                foods.setName(mFood_editText.getText().toString());
                foods.setDescription(mDesc_editText.getText().toString());
                foods.setPrice(mPrice_editText.getText().toString());

                new FirebaseDatabaseHelperRajitha().updateFood(key, foods, new FirebaseDatabaseHelperRajitha.DataStatus() {
                    @Override
                    public void DataIsLoaded(List<Foods> foods, List<String> keys) {

                    }

                    @Override
                    public void DataIsInserted() {

                    }

                    @Override
                    public void DataIsUpdated() {

                        Toast.makeText(FoodDetailsActivity.this,"Record Has Been Updated",Toast.LENGTH_LONG).show();
                    }

                    @Override
                    public void DataIsDeleted() {

                    }
                });

            }
        });

        mDelete_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new FirebaseDatabaseHelperRajitha().deleteBook(key, new FirebaseDatabaseHelperRajitha.DataStatus() {
                    @Override
                    public void DataIsLoaded(List<Foods> foods, List<String> keys) {

                    }

                    @Override
                    public void DataIsInserted() {

                    }

                    @Override
                    public void DataIsUpdated() {

                    }

                    @Override
                    public void DataIsDeleted() {

                        Toast.makeText(FoodDetailsActivity.this,"Delete Successfull",Toast.LENGTH_LONG).show();
                        finish(); return;
                    }
                });
            }
        });

        mBack_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                finish(); return;
            }
        });

    }


}
