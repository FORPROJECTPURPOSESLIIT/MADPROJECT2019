package com.example.businessapp;

import android.support.annotation.NonNull;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;


public class FirebaseDatabaseHelper {

    private FirebaseDatabase mDatabse;
    private DatabaseReference mReferenceContactus;
    private List<Contactus> contact = new ArrayList<>();

    public interface DataStatus{

        void DataIsLoaded(List<Contactus> contact, List<String> keys);
        void DataIsInserted();
        void DataIsUpdated();
        void DataIsDeleted();

    }


    public FirebaseDatabaseHelper() {

        mDatabse = FirebaseDatabase.getInstance();
        mReferenceContactus = mDatabse.getReference("contactus");
    }

    public void readContactus(final DataStatus dataStatus){

        mReferenceContactus.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                contact.clear();
                List<String> keys = new ArrayList<>();
                for(DataSnapshot keyNode : dataSnapshot.getChildren()){

                    keys.add(keyNode.getKey());
                    Contactus contactus = keyNode.getValue(Contactus.class);
                    contact.add(contactus);

                }

                dataStatus.DataIsLoaded(contact,keys);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }

   public void addInquiry(Contactus contactus, final DataStatus dataStatus){

     String key = mReferenceContactus.push().getKey();
     mReferenceContactus.child(key).setValue(contactus).addOnSuccessListener(new OnSuccessListener<Void>() {
         @Override
         public void onSuccess(Void aVoid) {

             dataStatus.DataIsInserted();

         }
     });

   }

   public void updateInquiry(String key, Contactus contactus, final DataStatus dataStatus){

        mReferenceContactus.child(key).setValue(contactus).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void aVoid) {

                dataStatus.DataIsUpdated();

            }
        });
   }

   public void deleteInquiry(String key, final DataStatus dataStatus){

        mReferenceContactus.child(key).setValue(null).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void aVoid) {

                dataStatus.DataIsDeleted();

            }
        });

   }

}

