package com.example.businessapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.List;

public class NewFoodActivity extends AppCompatActivity {

    private EditText mFoodName_editTxt;
    private EditText mDescription_editTxt;
    private EditText mPrice_editTxt;

    private Button mAdd_btn;
    private Button mBack_btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_food);
        mFoodName_editTxt = findViewById(R.id.insertFoodName);
        mDescription_editTxt = findViewById(R.id.insertDescription);
        mPrice_editTxt = findViewById(R.id.insertPrice);


        mAdd_btn = findViewById(R.id.update);
        mBack_btn = findViewById(R.id.back);

        mAdd_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Foods foods = new Foods();
                foods.setName(mFoodName_editTxt.getText().toString());
                foods.setDescription(mDescription_editTxt.getText().toString());
                foods.setPrice(mPrice_editTxt.getText().toString());
                new FirebaseDatabaseHelperRajitha().addFood(foods, new FirebaseDatabaseHelperRajitha.DataStatus() {
                    @Override
                    public void DataIsLoaded(List<Foods> foods, List<String> keys) {

                    }

                    @Override
                    public void DataIsInserted() {

                        Toast.makeText(NewFoodActivity.this, "Food Has been Inserted Successfully",Toast.LENGTH_LONG).show();

                    }

                    @Override
                    public void DataIsUpdated() {

                    }

                    @Override
                    public void DataIsDeleted() {

                    }
                });
            }
        });

        mBack_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                finish(); return;
            }
        });
    }
}
