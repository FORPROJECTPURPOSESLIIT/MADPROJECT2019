package com.example.businessapp;

public class UserProfile {

    public String email, name, phoneNumber, review, address;


    public UserProfile(){

    }

    public UserProfile(String email, String name, String phoneNumber) {
        this.email = email;
        this.name = name;
        this.phoneNumber = phoneNumber;
    }

    public UserProfile(String email, String name, String phoneNumber, String review) {
        this.email = email;
        this.name = name;
        this.phoneNumber = phoneNumber;
        this.review = review;
    }

    public UserProfile(String email, String name, String phoneNumber, String review, String address) {
        this.email = email;
        this.name = name;
        this.phoneNumber = phoneNumber;
        this.review = review;
        this.address = address;
    }

    public String getEmail() {
        return email;
    }

    public String getName() {
        return name;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public String getReview() {
        return review;
    }

    public String getAddress() {
        return address;
    }
}
