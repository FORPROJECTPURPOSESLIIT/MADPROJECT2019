package com.example.businessapp;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class Login extends AppCompatActivity {

    private Button button;
    private int RC_SIGN_IN = 1;
    private EditText email, password;
    private String email_user, password_user, TAG = "Login";
    private FirebaseAuth firebaseAuth;
    private String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        firebaseAuth = FirebaseAuth.getInstance();

        button = findViewById(R.id.login_btn);
        email  = findViewById(R.id.email_reset);
        password = findViewById(R.id.password_login);


    }

    public void resetPassword(View view){
        startActivity(new Intent(this, PasswordReset.class));
    }


    public void login(View view)
    {
        email_user = email.getText().toString().trim();
        password_user = password.getText().toString().trim();

        if(validate() == true) {
            firebaseAuth.signInWithEmailAndPassword(email_user, password_user).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    if(task.isSuccessful()) {
                        //Toast.makeText(Login.this,"Login Successful!", Toast.LENGTH_SHORT).show();

                        if(email_user.contains("eatmecontactportal@gmail.com")){
                            Toast.makeText(Login.this,"Login Successful!", Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(Login.this, AdminPanel.class));
                        }else{
                            Toast.makeText(Login.this,"Login Successful!", Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(Login.this, Home.class));
                        }


                    }else{
                        Toast.makeText(Login.this,"Wrong Password, Try again!", Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }
    }

    public boolean validate(){

        email_user = email.getText().toString().trim();
        password_user = password.getText().toString().trim();

        if(email_user.isEmpty() || password_user.isEmpty()){
            Toast.makeText(getApplicationContext(),"Fill all the Details!", Toast.LENGTH_LONG).show();
            return false;
        }else{
            if (email_user.matches(emailPattern)){
                    return true;
            }else{
                Toast.makeText(getApplicationContext(),"Invalid email address!", Toast.LENGTH_LONG).show();
                return false;
            }
        }
    }

}
