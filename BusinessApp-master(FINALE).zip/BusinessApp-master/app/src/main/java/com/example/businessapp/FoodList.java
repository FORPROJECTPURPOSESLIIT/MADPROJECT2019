package com.example.businessapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.view.View;

import java.util.List;

public class FoodList extends AppCompatActivity {

    private RecyclerView mRecyclerView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_food_list);
        mRecyclerView = (RecyclerView)findViewById(R.id.recyclerview_foods);
        new FirebaseDatabaseHelperRajitha().readFood(new FirebaseDatabaseHelperRajitha.DataStatus() {
            @Override
            public void DataIsLoaded(List<Foods> foods, List<String> keys) {
                findViewById(R.id.food_load).setVisibility(View.GONE);
                new RecyclerView_ConfigRajitha().setConfig(mRecyclerView,FoodList.this,
                        foods,keys);
            }

            @Override
            public void DataIsInserted() {

            }

            @Override
            public void DataIsUpdated() {

            }

            @Override
            public void DataIsDeleted() {

            }
        });
    }



}
