package com.example.businessapp;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class UserSettings extends AppCompatActivity {

    private FirebaseAuth firebaseAuth;
    private FirebaseDatabase firebaseDatabase;
    private EditText name, phone, address;
    private Button submit, chang_pwd;
    private String name_update, phone_update, review_update, email_update, address_update;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_settings);

        name = findViewById(R.id.name_edit);
        phone = findViewById(R.id.phone_edit);
        address = findViewById(R.id.address_edit);

        submit = findViewById(R.id.btneditsubmit);
        chang_pwd = findViewById(R.id.btnchngpassword);

        firebaseAuth = FirebaseAuth.getInstance();
        firebaseDatabase = FirebaseDatabase.getInstance();

        //final DatabaseReference databaseReference = firebaseDatabase.getReference(firebaseAuth.getUid());

        FirebaseUser user=FirebaseAuth.getInstance().getCurrentUser();
        final String userid=user.getUid();

        final DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("Users");

        databaseReference.child(userid).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                UserProfile userProfile = dataSnapshot.getValue(UserProfile.class);

                name_update = userProfile.getName();
                phone_update = userProfile.getPhoneNumber();
                review_update = userProfile.getReview();
                email_update = userProfile.getEmail();
                address_update = userProfile.getAddress();

                name.setText(userProfile.getName());
                phone.setText(userProfile.getPhoneNumber());
                address.setText(userProfile.getAddress());

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(UserSettings.this, databaseError.getCode(),  Toast.LENGTH_SHORT).show();
            }
        });

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String phone_edited = phone.getText().toString();
                String name_edited = name.getText().toString();
                String address_edited = address.getText().toString();

                UserProfile userProfile = new UserProfile(email_update, name_edited, phone_edited, review_update, address_edited);

                databaseReference.child(userid).setValue(userProfile);

                finish();
                startActivity(getIntent());
            }
        });

        chang_pwd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(UserSettings.this, new_password_chng.class);
                startActivity(intent);
            }
        });
    }
}
