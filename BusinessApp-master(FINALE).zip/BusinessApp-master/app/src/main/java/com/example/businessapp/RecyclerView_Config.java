package com.example.businessapp;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.List;

public class RecyclerView_Config {



    private Context mContext;
    private ContactusAdapter mCntactusAdapter;
    public void setConfig(RecyclerView recyclerView, Context context, List<Contactus> contactuses, List<String> keys){
         mContext = context;
         mCntactusAdapter = new ContactusAdapter(contactuses, keys);
         recyclerView.setLayoutManager(new LinearLayoutManager(context));
         recyclerView.setAdapter(mCntactusAdapter);





    }


    class ContactItemView extends RecyclerView.ViewHolder {

        private TextView mName;
        private TextView mEmail;
        private TextView mContact;
        private TextView mMessage;


        private String key;

        public ContactItemView(ViewGroup parent){

           super(LayoutInflater.from(mContext).inflate(R.layout.contact_list_item, parent, false));

           mName = (TextView) itemView.findViewById(R.id.textViewName);
           mEmail = (TextView) itemView.findViewById(R.id.textViewemail);
           mContact = (TextView) itemView.findViewById(R.id.textViewcontact);
           mMessage = (TextView) itemView.findViewById(R.id.textViewmessage);



           itemView.setOnClickListener(new View.OnClickListener() {
               @Override
               public void onClick(View v) {

                   Intent intent = new Intent(mContext, ContactusDetailsActivity.class);
                   intent.putExtra("key",key);
                   intent.putExtra("name", mName.getText().toString());
                   intent.putExtra("email", mEmail.getText().toString());
                   intent.putExtra("contact", mContact.getText().toString());
                   intent.putExtra("message", mMessage.getText().toString());

                   mContext.startActivity(intent);


               }
           });

        }

         public void bind(Contactus contactus, String key){

            mName.setText(contactus.getName());
            mEmail.setText(contactus.getEmail());
            mContact.setText(contactus.getContact());
            mMessage.setText(contactus.getMessage());
            this.key = key;

         }

    }

    class ContactusAdapter extends RecyclerView.Adapter<ContactItemView>{

          private List<Contactus> mContactList;
          private List<String> mkeys;

        public ContactusAdapter(List<Contactus> mContactList, List<String> mkeys) {
            this.mContactList = mContactList;
            this.mkeys = mkeys;
        }

        @Override
        public int getItemCount() {
            return mContactList.size();
        }

        @Override
        public ContactItemView onCreateViewHolder(ViewGroup parent, int viewType) {
            return new ContactItemView(parent);
        }

        @Override
        public void onBindViewHolder(ContactItemView holder, int position) {

            holder.bind(mContactList.get(position), mkeys.get(position));

        }
    }






}
