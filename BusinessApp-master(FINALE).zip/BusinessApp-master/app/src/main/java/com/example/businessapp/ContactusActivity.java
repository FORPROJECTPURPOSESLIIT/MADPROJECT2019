package com.example.businessapp;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.RecyclerView;

import java.util.List;

public class ContactusActivity extends AppCompatActivity {

    private RecyclerView mRecyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contactus);
        mRecyclerView = (RecyclerView) findViewById(R.id.recycle_viewcontact);
        new FirebaseDatabaseHelper().readContactus(new FirebaseDatabaseHelper.DataStatus() {
            @Override
            public void DataIsLoaded(List<Contactus> contact, List<String> keys) {



                new RecyclerView_Config().setConfig(mRecyclerView, ContactusActivity.this, contact, keys);
            }

            @Override
            public void DataIsInserted() {

            }

            @Override
            public void DataIsUpdated() {

            }

            @Override
            public void DataIsDeleted() {

            }
        });




    }
}
