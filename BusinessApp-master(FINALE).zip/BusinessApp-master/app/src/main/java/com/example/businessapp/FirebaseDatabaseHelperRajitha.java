package com.example.businessapp;

import android.support.annotation.NonNull;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class FirebaseDatabaseHelperRajitha {

    private FirebaseDatabase mDatabase;
    private DatabaseReference mReferenceFoods;
    private List<Foods> foods = new ArrayList<>();

    public interface DataStatus
    {
        void DataIsLoaded(List<Foods> foods, List<String> keys);
        void DataIsInserted();
        void DataIsUpdated();
        void DataIsDeleted();

    }

    public FirebaseDatabaseHelperRajitha() {
        mDatabase = FirebaseDatabase.getInstance();
        mReferenceFoods = mDatabase.getReference("Foods");
    }

    public void readFood( final DataStatus dataStatus)
    {
        mReferenceFoods.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                foods.clear();
                List<String> keys = new ArrayList<>();
                for (DataSnapshot keyNode : dataSnapshot.getChildren())
                {
                    keys.add(keyNode.getKey());
                    Foods food = keyNode.getValue(Foods.class);
                    foods.add(food);
                }
                dataStatus.DataIsLoaded(foods,keys);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }
    public void addFood (Foods foods, final DataStatus dataStatus)
    {
        String key = mReferenceFoods.push().getKey();
        mReferenceFoods.child(key).setValue(foods)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {

                        dataStatus.DataIsInserted();
                    }
                });
    }


    public void updateFood(String key, Foods foods, final DataStatus dataStatus )
    {

        mReferenceFoods.child(key).setValue(foods)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        dataStatus.DataIsUpdated();
                    }
                });
    }

    public void deleteBook(String key, final DataStatus dataStatus)
    {
        mReferenceFoods.child(key).setValue(null)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {

                        dataStatus.DataIsDeleted();
                    }
                });
    }
}
