package com.example.businessapp;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.List;


public class FeedBack extends AppCompatActivity  {

    private EditText mName_editTxt;
    private EditText mEmail_editTxt;
    private EditText mContact_editTxt;
    private  EditText mMessage_editTxt;

    private Button btn1;
    private Button btnBack;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_feed_back);



        mName_editTxt = (EditText) findViewById(R.id.editText4);
        mEmail_editTxt = (EditText) findViewById(R.id.editText7);
        mContact_editTxt = (EditText) findViewById(R.id.editText8);
        mMessage_editTxt = (EditText) findViewById(R.id.editText10);

        btnBack = (Button) findViewById(R.id.button);

        btn1 = (Button) findViewById(R.id.buttonSend);



        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Contactus contactus = new Contactus();
                contactus.setName(mName_editTxt.getText().toString());
                contactus.setEmail(mEmail_editTxt.getText().toString());
                contactus.setContact(mContact_editTxt.getText().toString());
                contactus.setMessage(mMessage_editTxt.getText().toString());



                if(mName_editTxt.getText().toString().equals("")){

                    mName_editTxt.setError("Please enter valid name");
                }
                else if(mEmail_editTxt.getText().toString().equals("")){

                    mEmail_editTxt.setError("Please enter valid email address");
                }
                else if(mContact_editTxt.getText().toString().equals("")){

                    mContact_editTxt.setError("Please enter valid contact number");
                }
                else if(mMessage_editTxt.getText().toString().equals("")){

                    mMessage_editTxt.setError("Please enter valid message");


                }
                else {
                    openContactusActivity();


                    new FirebaseDatabaseHelper().addInquiry(contactus, new FirebaseDatabaseHelper.DataStatus() {
                        @Override
                        public void DataIsLoaded(List<Contactus> contact, List<String> keys) {

                        }

                        @Override
                        public void DataIsInserted() {

                            Toast.makeText(FeedBack.this, "Data entered successfully", Toast.LENGTH_LONG).show();


                        }

                        @Override
                        public void DataIsUpdated() {

                        }

                        @Override
                        public void DataIsDeleted() {

                        }

                    });
                }
            }
        });

          btnBack.setOnClickListener(new View.OnClickListener() {
              @Override
              public void onClick(View v) {

                  finish(); return;
              }
          });





    //    btn1.setOnClickListener(new View.OnClickListener() {
    //        @Override
    //        public void onClick(View v) {
     //           openContactusActivity();
      //      }
      //  });



    }

      public void openContactusActivity(){

        Intent intent = new Intent(this, ContactusActivity.class);
        startActivity(intent);

      }






}
