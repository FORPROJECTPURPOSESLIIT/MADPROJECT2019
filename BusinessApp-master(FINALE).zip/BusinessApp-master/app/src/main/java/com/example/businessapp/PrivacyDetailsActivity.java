package com.example.businessapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.List;

public class PrivacyDetailsActivity extends AppCompatActivity {

    private EditText mPrivacy_editTxt;

    private Button mUpdate_btn;
    private Button mDelete_btn;
    private Button mBack_btn;

    private String rules;
    private String key;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_privacy_details);

        key = getIntent().getStringExtra("key");
        rules = getIntent().getStringExtra("rules");




        mPrivacy_editTxt = (EditText) findViewById(R.id.privacy_rule);
        mPrivacy_editTxt.setText(rules);

        mUpdate_btn = (Button) findViewById(R.id.privacy_update);
        mDelete_btn = (Button) findViewById(R.id.delete_privacy);
        mBack_btn = (Button) findViewById(R.id.button_back);

        mUpdate_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                PrivacyRules privacyRules = new PrivacyRules();
                privacyRules.setRules(mPrivacy_editTxt.getText().toString());

                if(mPrivacy_editTxt.getText().toString().equals("")){

                    mPrivacy_editTxt.setError("Please enter valid privacy policy!");
                }
                else {
                    new FirebaseDatabaseHelperPrivacy().updatePrivacy(key, privacyRules, new FirebaseDatabaseHelperPrivacy.DataStatus() {
                        @Override
                        public void DataIsLoaded(List<PrivacyRules> privacy, List<String> keys) {

                        }

                        @Override
                        public void DataIsInserted() {

                        }

                        @Override
                        public void DataIsUpdated() {

                            Toast.makeText(PrivacyDetailsActivity.this, "Updated successfully", Toast.LENGTH_LONG).show();
                        }

                        @Override
                        public void DataIsDeleted() {

                        }
                    });
                }
            }
        });

        mDelete_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                new FirebaseDatabaseHelperPrivacy().deletePrivacy(key, new FirebaseDatabaseHelperPrivacy.DataStatus() {
                    @Override
                    public void DataIsLoaded(List<PrivacyRules> privacy, List<String> keys) {

                    }

                    @Override
                    public void DataIsInserted() {

                    }

                    @Override
                    public void DataIsUpdated() {

                    }

                    @Override
                    public void DataIsDeleted() {

                        Toast.makeText(PrivacyDetailsActivity.this, "Deleted successfully", Toast.LENGTH_LONG).show();
                        finish(); return;
                    }
                });

            }
        });

        mBack_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                finish();return;
            }
        });

    }
}
