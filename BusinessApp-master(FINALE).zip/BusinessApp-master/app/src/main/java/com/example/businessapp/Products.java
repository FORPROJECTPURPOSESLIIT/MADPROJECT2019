package com.example.businessapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Products extends AppCompatActivity {

    Button btn1,btn2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_special_order);

        btn1= findViewById(R.id.angry_btn);
        btn2=findViewById(R.id.angry_btn2);

    }

    public void Newinquiry(View view)
    {
        Intent intent=new Intent(this, NewFoodActivity.class);
        startActivity(intent);
    }

    public void Editinquiry(View view)
    {
        Intent intent=new Intent(this, FoodList.class);
        startActivity(intent);
    }



    public void Home(View view)
    {
        Intent intent=new Intent(this,AdminPanel.class);
        startActivity(intent);
    }
}
