package com.example.businessapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.List;

public class ContactusDetailsActivity extends AppCompatActivity {

    private EditText mName_editTxt;
    private EditText mEmail_editTxt;
    private EditText mContact_editTxt;
    private EditText mMessage_editText;

    private Button mUpdate_btn;
    private Button mDelete_btn;
    private Button mBack_btn;

    private String key;
    private String name;
    private String email;
    private String contact;
    private String message;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contactus_details);

        key = getIntent().getStringExtra("key");
        name = getIntent().getStringExtra("name");
        email = getIntent().getStringExtra("email");
        contact = getIntent().getStringExtra("contact");
        message = getIntent().getStringExtra("message");


        mName_editTxt = (EditText) findViewById(R.id.editText4);
        mName_editTxt.setText(name);
        mEmail_editTxt = (EditText) findViewById(R.id.editText7);
        mEmail_editTxt.setText(email);
        mContact_editTxt = (EditText) findViewById(R.id.editText8);
        mContact_editTxt.setText(contact);
        mMessage_editText = (EditText) findViewById(R.id.editText10);
        mMessage_editText.setText(message);

        mUpdate_btn = (Button) findViewById(R.id.Update);
        mDelete_btn = (Button) findViewById(R.id.buttonDelete);
        mBack_btn = (Button) findViewById(R.id.button);


        mUpdate_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

              Contactus contactus = new Contactus();
              contactus.setName(mName_editTxt.getText().toString());
              contactus.setEmail(mEmail_editTxt.getText().toString());
              contactus.setContact(mContact_editTxt.getText().toString());
              contactus.setMessage(mMessage_editText.getText().toString());

                if(mName_editTxt.getText().toString().equals("")){

                    mName_editTxt.setError("Please enter valid name");
                }
                else if(mEmail_editTxt.getText().toString().equals("")){

                    mEmail_editTxt.setError("Please enter valid email address");
                }
                else if(mContact_editTxt.getText().toString().equals("")){

                    mContact_editTxt.setError("Please enter valid contact number");
                }
                else if(mMessage_editText.getText().toString().equals("")){

                    mMessage_editText.setError("Please enter valid message");


                }
                else {

                    new FirebaseDatabaseHelper().updateInquiry(key, contactus, new FirebaseDatabaseHelper.DataStatus() {
                        @Override
                        public void DataIsLoaded(List<Contactus> contact, List<String> keys) {

                        }

                        @Override
                        public void DataIsInserted() {

                        }

                        @Override
                        public void DataIsUpdated() {

                            Toast.makeText(ContactusDetailsActivity.this, "Details updated successfully", Toast.LENGTH_LONG).show();
                        }

                        @Override
                        public void DataIsDeleted() {

                        }
                    });

                }
            }
        });

        mDelete_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                new FirebaseDatabaseHelper().deleteInquiry(key, new FirebaseDatabaseHelper.DataStatus() {
                    @Override
                    public void DataIsLoaded(List<Contactus> contact, List<String> keys) {

                    }

                    @Override
                    public void DataIsInserted() {

                    }

                    @Override
                    public void DataIsUpdated() {

                    }

                    @Override
                    public void DataIsDeleted() {

                        Toast.makeText(ContactusDetailsActivity.this, "Details deleted successfully", Toast.LENGTH_LONG).show();
                        finish(); return;
                    }
                });

            }
        });

        mBack_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                finish(); return;
            }
        });



    }
}
