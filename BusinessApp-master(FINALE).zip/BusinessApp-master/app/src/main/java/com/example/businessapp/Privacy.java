package com.example.businessapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.List;

public class Privacy extends AppCompatActivity {

    private EditText mRules_editTxt;

    private Button mAdd_btn;
    private Button mView_btn;
    private Button mBack_btn;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_privacy);

        mRules_editTxt = (EditText) findViewById(R.id.privacy_rule);

        mAdd_btn = (Button) findViewById(R.id.add_rule);
        mBack_btn = (Button) findViewById(R.id.button_back);
        mView_btn = (Button) findViewById(R.id.button_view);




        mAdd_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                PrivacyRules privacyRules = new PrivacyRules();
                privacyRules.setRules(mRules_editTxt.getText().toString());

                if(mRules_editTxt.getText().toString().equals("")){

                    mRules_editTxt.setError("Please enter valid privacy policy!");
                }

                else {
                    openNewprivacyActivity();
                    new FirebaseDatabaseHelperPrivacy().addPrivacy(privacyRules, new FirebaseDatabaseHelperPrivacy.DataStatus() {
                        @Override
                        public void DataIsLoaded(List<PrivacyRules> privacy, List<String> keys) {


                        }

                        @Override
                        public void DataIsInserted() {

                            Toast.makeText(Privacy.this, "The privacy policy has been entered successfully", Toast.LENGTH_LONG).show();

                        }

                        @Override
                        public void DataIsUpdated() {

                        }

                        @Override
                        public void DataIsDeleted() {

                        }
                    });
                }
            }

        });

     mBack_btn.setOnClickListener(new View.OnClickListener() {
         @Override
         public void onClick(View v) {

             finish(); return;
         }
     });

     mView_btn.setOnClickListener(new View.OnClickListener() {
         @Override
         public void onClick(View v) {
             openNewprivacyActivity();
         }
     });






    }



    public void openNewprivacyActivity(){

        Intent intent = new Intent(this, PrivacyListActivity.class);
        startActivity(intent);
    }
}
